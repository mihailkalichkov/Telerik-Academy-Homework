﻿using System;

namespace Task11_LinkedListImplementation
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
